Place the two files you download from the AWS Transform console here before
prompting the AI agent:

  1. bre_transform_debug_*.zip  (Artifacts tab -> 1 -> artifact-slicing)
  2. The original source zip submitted to the AWS Transform job

See ../README.md and ../skills/fix-atx-datapath-errors/SKILL.md for exact
collection steps.
