The agent writes its output here when you run the skill:

  - findings.json
  - annotated_findings.json
  - changelog.json
  - target_fixed.zip   (the fixed source, ready to re-submit to AWS Transform)
  - report.md          (summary of fixes, removals, and manual-review items)

This folder starts empty on purpose.
