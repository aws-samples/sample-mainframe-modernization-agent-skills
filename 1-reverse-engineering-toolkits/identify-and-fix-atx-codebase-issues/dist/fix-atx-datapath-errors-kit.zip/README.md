# Fix AWS Transform for Mainframe (ATX) Codebase Issues — AI Agent Kit

Diagnoses and fixes AWS Transform for mainframe "Discover data paths"
extraction errors/warnings on mainframe codebases (COBOL, PL/I, and other
supported source languages) using an AI coding agent.

## What's in this package

```
skills/fix-atx-datapath-errors/   the agent skill (scripts + instructions)
input/                            put your two downloaded files here
output/                           the agent writes its results here
README.md                         this file
```

## Prerequisites

- Python 3 installed and available on your `PATH` (check with
  `python3 --version`). No third-party packages are required — the
  skill's scripts use only Python's standard library.

## Setup

1. **Expand this zip** to a folder on your machine.
2. **Open that folder as a workspace in Kiro**, or place the
   `skills/fix-atx-datapath-errors/` folder in the equivalent path for
   another AI tool:

   | Tool | Where to place the skill folder |
   |---|---|
   | [Kiro](https://kiro.dev/docs/skills/) | `.kiro/skills/fix-atx-datapath-errors/` (workspace) or `~/.kiro/skills/fix-atx-datapath-errors/` (global) |
   | [Claude Code](https://code.claude.com/docs/en/skills) | `.claude/skills/fix-atx-datapath-errors/` (project) or `~/.claude/skills/fix-atx-datapath-errors/` (personal) |
   | [Codex](https://developers.openai.com/codex/build-skills) | `.agents/skills/fix-atx-datapath-errors/` (repo) or `~/.agents/skills/fix-atx-datapath-errors/` (global) |
   | [Cursor](https://cursor.com/docs/skills) | `.cursor/skills/fix-atx-datapath-errors/` or `.agents/skills/fix-atx-datapath-errors/` (project); `~/.cursor/skills/` or `~/.agents/skills/` (global) |
   | [GitHub Copilot](https://docs.github.com/en/copilot/how-tos/use-copilot-agents/coding-agent/create-skills) | `.github/skills/fix-atx-datapath-errors/` (project); `~/.copilot/skills/` or `~/.agents/skills/` (personal) |
   | [Devin](https://docs.devin.ai/product-guides/skills) | `.agents/skills/fix-atx-datapath-errors/` (commit to repo; also scans `.devin/`, `.github/`, `.claude/`, `.cursor/`, `.codex/` skills folders) |

   The skill follows the open [Agent Skills](https://agentskills.io)
   standard, so the folder works unmodified in any of them — just copy
   or symlink it to the path above, don't rename it.
3. **Collect two files from AWS Transform and place them in `input/`:**
   - `bre_transform_debug_*.zip` — in the AWS Transform console, open your
     job → **Artifacts** tab → **`1` → `artifact-slicing`** → download
     `bre_transform_debug_*.zip` (not `bre_output_*.zip`, not the
     obfuscated log).
   - The **original source zip** you submitted to that AWS Transform job.
4. **Prompt the agent**, for example:

   > Use the fix-atx-datapath-errors skill to analyze the files in
   > `input/` and fix what you can. Write results to `output/`.

The agent will parse the debug bundle, correlate findings against your
source, apply safe fixes, and produce `output/target_fixed.zip` plus
`output/report.md` summarizing everything fixed, left alone, or removed.
Re-submit `target_fixed.zip` to AWS Transform once you've reviewed the
report.

Full workflow detail and guardrails: `skills/fix-atx-datapath-errors/SKILL.md`.
